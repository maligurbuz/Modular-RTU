Use of all, or part, of the PLC Demo System's gerbers is at your own risk.
Request that these gerbers not be distributed outside your company/organisation.